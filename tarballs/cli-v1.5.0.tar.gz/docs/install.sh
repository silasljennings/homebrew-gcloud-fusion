#!/usr/bin/env bash
#
# install.sh - gcloud-fusion Installation
#
# This script redirects users to the modern Homebrew installation.
#

set -euo pipefail

echo "🍺 gcloud-fusion Installation"
echo
echo "gcloud-fusion is now distributed via Homebrew for the best experience."
echo
echo "📦 Install with Homebrew:"
echo "   brew tap silasljennings/gcloud-fusion"
echo "   brew install gcloud-fusion"
echo
echo "✅ Benefits of Homebrew:"
echo "   • Automatic dependency management"
echo "   • Easy updates: brew upgrade gcloud-fusion"
echo "   • Clean uninstall: brew uninstall gcloud-fusion"
echo "   • Commands available immediately"
echo "   • No manual setup required"
echo
echo "🚀 After installation, try these commands:"
echo "   help              # Show all available commands"
echo "   create-repo       # Create GitHub repositories"
echo "   set-project       # Switch GCP projects"
echo "   create-emulator   # Set up Firebase emulators"
echo
echo "📖 Documentation: https://gcloud-fusion.devdeviants.com"
echo

# Check if Homebrew is available
if command -v brew &>/dev/null; then
    echo "✅ Homebrew detected!"
    echo
    echo -n "Install gcloud-fusion now? (Y/n): "
    read -r INSTALL_NOW
    INSTALL_NOW="${INSTALL_NOW:-y}"

    if [[ "$INSTALL_NOW" =~ ^[Yy]$ ]]; then
        echo
        echo "🚀 Installing gcloud-fusion via Homebrew..."

        if brew tap silasljennings/gcloud-fusion && brew install gcloud-fusion; then
            echo
            echo "🎉 Installation complete!"
            echo "Try running: help"
        else
            echo
            echo "❌ Installation failed. Please check your Homebrew setup."
        fi
    else
        echo
        echo "📋 Manual installation commands:"
        echo "   brew tap silasljennings/gcloud-fusion"
        echo "   brew install gcloud-fusion"
    fi
else
    echo "⚠️  Homebrew not found."
    echo
    echo "📥 Install Homebrew first:"
    echo '   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
    echo
    echo "Then install gcloud-fusion:"
    echo "   brew tap silasljennings/gcloud-fusion"
    echo "   brew install gcloud-fusion"
fi

echo
