---
title: Install gcloud-fusion
---

# Installation

## Homebrew (Recommended)

Install gcloud-fusion via Homebrew:

```bash
brew tap silasljennings/gcloud-fusion
brew install gcloud-fusion
```

### Upgrade

To upgrade to the latest version:

```bash
brew upgrade gcloud-fusion
```

### Uninstall

To completely uninstall gcloud-fusion:

```bash
brew uninstall gcloud-fusion
brew untap silasljennings/gcloud-fusion
```

## Migration from Legacy Installation

If you previously installed gcloud-fusion via the old method, migrate to Homebrew:

1. Install via Homebrew (see above)
2. Remove legacy installation: `rm -rf ~/.local/gcloud-fusion`
3. Remove shell functions from your `~/.zshrc` or `~/.bashrc` (look for "Project Script Shortcuts" section)
4. Restart your shell: `source ~/.zshrc`

## Getting Started

After installation, all commands are available directly:

```bash
help              # Show all available commands
create-repo       # Create a GitHub repository
set-project       # Switch GCP projects
create-emulator   # Set up Firebase emulators
```

Authentication will be handled automatically when you first run commands.
