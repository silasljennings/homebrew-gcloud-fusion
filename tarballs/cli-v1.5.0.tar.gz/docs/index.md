---
title: gcloud-fusion documentation
---

- [Installation Instructions](install.html)
- [Changelog](changelog.html)

## Overview

gcloud-fusion is a CLI tool that streamlines the development workflow by combining Google Cloud Platform (GCP), Firebase, and GitHub operations into simple, unified commands.

By definition, Firebase is Google's mobile development platform built on top of Google Cloud Platform. While Firebase provides an interactive console for managing services like Firestore, Cloud Functions, and Authentication, developers often need to work across both Firebase and GCP consoles for comprehensive project management.

gcloud-fusion eliminates this complexity by providing a single CLI interface that "fuses" the gcloud CLI, Firebase CLI, and GitHub CLI together. This allows developers to automate common development tasks and focus on building applications rather than managing infrastructure.

Key integrations include:
- **Google Cloud Platform**: Project management, Secret Manager, Artifact Registry, Cloud Build triggers
- **Firebase**: Project creation, emulator setup, service configuration
- **GitHub**: Repository management, SSH key handling, CI/CD integration

The tool provides pre-configured commands for the most common development workflows, with automatic authentication handling to ensure a seamless developer experience.

## Installation

Install gcloud-fusion via Homebrew:

```bash
brew tap silasljennings/gcloud-fusion
brew install gcloud-fusion
```

### Dependencies

All dependencies are automatically installed by Homebrew:

- **google-cloud-sdk** - Google Cloud CLI for GCP operations
- **firebase-cli** - Firebase CLI for Firebase operations
- **gh** - GitHub CLI for repository management
- **git** - Version control system
- **node** - Required for Firebase CLI functionality

### Prerequisites

Before using gcloud-fusion, you'll need:

1. **Google Cloud Account**: Sign up at [console.cloud.google.com](https://console.cloud.google.com/freetrial/signup/)
2. **Firebase Account**: Sign in at [firebase.google.com](https://firebase.google.com/) with the same Google account
3. **GitHub Account**: Required for repository operations

Authentication for all services happens automatically when you first run commands - no manual setup required!

## Available Commands

### Google Cloud Platform

| Command | Description |
|---------|-------------|
| `set-project` | Switch to a specific GCP project and configure authentication |
| `create-secret` | Create or update secrets in Google Cloud Secret Manager |
| `create-artifact` | Create Artifact Registry repositories for container images |
| `create-trigger` | Set up Cloud Build triggers for CI/CD automation |
| `create-host` | Connect GitHub as a source repository host in GCP |
| `link-repo` | Link GitHub repositories to GCP projects for integration |
| `create-cloudbuild` | Generate cloudbuild.yaml configuration files |
| `create-dockerfile` | Create optimized Dockerfile templates |

### Firebase

| Command | Description |
|---------|-------------|
| `create-emulator` | Set up Firebase emulator suite for local development |
| `run-emulator` | Start Firebase emulators for testing |
| `create-project` | Create new Firebase projects |
| `get-sak` | Export Firebase service account keys |
| `get-request` | Convert JSON data to HTTP request files |

### GitHub

| Command | Description |
|---------|-------------|
| `create-repo` | Create new GitHub repositories with customizable settings |
| `delete-repo` | Delete GitHub repositories with confirmation prompts |
| `get-repo` | Clone repositories with SSH key configuration |
| `set-remote` | Update repository remote origins |
| `set-visibility` | Change repository visibility (public/private) |
| `create-ssh` | Generate and add SSH keys to GitHub account |
| `delete-ssh` | Remove SSH keys from GitHub account |
| `create-ignore` | Generate .gitignore files for various project types |

### Local Development

| Command | Description |
|---------|-------------|
| `copy-repo` | Copy repository contents without .git directory |
| `get-boiler` | Interactive boilerplate project setup |
| `create-app` | Create new application projects |
| `kport` | Port management utilities |

### Utilities

| Command | Description |
|---------|-------------|
| `help` | Display comprehensive help and command documentation |

Run any command to get started - authentication will be handled automatically on first use.

## Common Use Cases

### Scenario 1

A quick way to clone a repository from GitHub (yours or another users) and replicate it to a new repository in your account.
This would be useful for taking a boilerplates or starter kit from GitHub and replicating it into your GitHub account quickly.

1. Create new repository
2. Clone a repository (yours or another user)
3. Set the cloned repository remote to the new repository remote
4. Push the contents of the cloned repository to the new repository

```
    create-repo
    get-repo
    set-remote
    git add .
    git commit -m 'intitial commit'
    git push -u origin main
```

### Scenario 2

A quick way to take a local code base that is already associated with a GitHub repository and point it to a newly created repository.
This also would be a good way to take the contents of existing codebases, boilerplates, or starter kits that already exist on your machine
pushed up to a newly created repository.

1. Copy local repository directory to a new folder without associate .git artifacts
2. In the new directory created when copied, initialize a new .git repository
3. Create and configure a new .gitignore
4. Create a new repository to push to
5. Set the repository remote to the new repository remote
6. Push the contents of the cloned repository to the new repository

```
    copy-repo
    git init
    create-ignore
    create-repo
    set-remote
    git add .
    git commit -m 'intiial commit'
    git push -u origin main
```
