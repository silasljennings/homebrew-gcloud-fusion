---
title: gcloud-fusion changelog
---

# Changelog

All notable changes to the gcloud-fusion toolkit are documented in this file.

## [0.0.1] – 2025-05-30
### Added
- `gif-create-emulator` command for launching local Firebase emulators.
- Offline documentation included in each release under `versions/<ver>/docs/`.

## [0.0.2] – 2025-05-30
### Added
- Initial support for `create-project` (automatically create a new GCP project and initialize Firestore).

### Changed
- Moved `docs/` into each `versions/<ver>/docs/` subfolder for offline snapshots.
- Adjusted `install.sh` to respect custom user-passed versions.

## [0.0.3] – 2025-06-01
### Added
- Multiple GitHub-related commands: toggling visibility, cloning, deleting/creating repos, and SSH key management.

## [0.0.4] – 2025-06-01
### Added
- Automated versioning
- Updated install and setup script

## [0.0.5] – 2025-06-01
### Added
- Updated documentation, changelog, etc.

## [0.0.6] – 2025-06-01
### Added
- Updated tar link to storage bucket